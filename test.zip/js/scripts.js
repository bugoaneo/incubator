// Initialise Carousel
const mainCarousel = new Carousel(document.querySelector("#mainCarousel"), {
 Dots: false,
 slidesToSlide: 3,
});


// Customize Fancybox
Fancybox.bind('[data-fancybox="gallery"]', {
 // Carousel: {
 //  on: {
 //   change: (that) => {
 //    mainCarousel.slideTo(mainCarousel.findPageForSlide(that.page), {
 //     friction: 0,
 //    });
 //   },
 //  },
 // },
 Thumbs: {
  autoStart: false,
 },
 Toolbar: false,
});