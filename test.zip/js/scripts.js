// // Initialise Carousel
// const mainCarousel = new Carousel(document.querySelector("#mainCarousel"), {
//  Dots: false,
//  // slidesToSlide: 3,
// });


// // Customize Fancybox
// Fancybox.bind('[data-fancybox="gallery"]', {
//  // Carousel: {
//  //  on: {
//  //   change: (that) => {
//  //    mainCarousel.slideTo(mainCarousel.findPageForSlide(that.page), {
//  //     friction: 0,
//  //    });
//  //   },
//  //  },
//  // },
//  Thumbs: {
//   autoStart: false,
//  },
//  Toolbar: false,
// });

document.addEventListener('DOMContentLoaded', function (event) {
 var glide = new Glide('.glide', {
  type: 'carousel',
  perView: 3,
  focusAt: 'center',
  breakpoints: {
   800: {
    perView: 2
   },
   600: {
    focusAt: 0,
    perView: 1,
    peek: { before: 19, after: 19 }
   },
  }
 })

 glide.mount()


 baguetteBox.run('.glide__slides');

})
