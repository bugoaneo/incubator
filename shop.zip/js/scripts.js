$('.menu-trigger').click(function () {
 $('.menu').addClass('open');
 $('.main-menu_open').addClass('open');
 $('body').addClass('overflow');
});


$(document).mouseup(function (e) {
 if (!$('.menu').is(e.target) && $('.menu').has(e.target).length === 0) {
  $('.menu').removeClass('open');
 }
});


$('.main-menu_open').click(function () {
 $('.menu').removeClass('open');
 $(this).removeClass('open');
 $('body').removeClass('overflow');
});

$('.menu__more').click(function () {
 $(this).next('.dropdown__wrapper').toggleClass('open');
});

$('.menu__header .menu__more').click(function () {
 $(this).closest('.dropdown__wrapper').toggleClass('open');
});

$('.dropdown__menu-item .menu__more').click(function () {
 $('.dropdown__container').toggleClass('open');
});




// if (window.matchMedia("(max-width: 900px)").matches) {
//  $('.dropdown__submenu').removeClass('current');
// }